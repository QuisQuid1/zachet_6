﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace зачет_6
{
    public partial class Form1 : Form
    {
        private List<Country> countries;
        private List<Hotel> hotels;
        public Form1()
        {
            InitializeComponent();
            LoadData();
            dataGridView1.Columns.Add("Type","Тип");
            dataGridView1.Columns.Add("ID","ID отеля");
            dataGridView1.Columns.Add("Name","Название");
            dataGridView1.Columns.Add("Price","Цена");
        }
        private void LoadData()
        {
            countries = new List<Country>
            {
                new Country { ID = 1, Name = "USA" },
                new Country { ID = 2, Name = "Canada" },
                new Country { ID = 3, Name = "UK" },
                new Country { ID = 4, Name = "France" }
            };

            hotels = new List<Hotel>
            {
                new Hotel { Type = "Hotel", ID = 1, Name = "Hilton", Price = 150.0 },
                new Hotel { Type = "Resort", ID = 2, Name = "Marriott", Price = 200.0 },
                new Hotel { Type = "Hotel", ID = 3, Name = "Sheraton", Price = 180.0 },
                new Hotel { Type = "Resort", ID = 4, Name = "Hyatt", Price = 250.0 }
            };
        }
        private Hotel AddHotel()
        {
            Hotel hotel = new Hotel
            {
                Type = textBox1.Text,
                ID = hotels.Count + 1,
                Name = textBox2.Text,
                Price = double.Parse(textBox3.Text)
            };
            return hotel;
        }
        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hotel newHotel = AddHotel();
            hotels.Add(newHotel);
        }
    }

}

